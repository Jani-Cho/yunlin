﻿<?php 
if(isset($_POST['add_project'])){

    $wsl_cats = $_POST['wsl_cats']; //案件類別
    
    if(isset($_POST['wsl_source'])){
        $wsl_source = $_POST['wsl_source']; //查報主資訊來源
    } else {
        $wsl_source = ""; 
    }
    $wsl_county = $_POST['wsl_county']; //實施地點 土地座落 縣
    $wsl_town = $_POST['wsl_town']; //鄉市
    $wsl_alley = $_POST['wsl_alley']; //路段
    
    $wsl_unit = $_POST['wsl_unit']; //案件移來單位
    $wsl_apy_date = date('Y-m-d', strtotime($_POST['wsl_apy_date'])); //查(通)報日期
    $wsl_apy_num = $_POST['wsl_apy_num']; //查(通)報文號
    
    $wsl_sent_date = date('Y-m-d', strtotime($_POST['wsl_sent_date'])); //農村發展及水土保持署函送日期
    $wsl_sent_num = $_POST['wsl_sent_num']; //農村發展及水土保持署函送文號
 
    $wsl_acp_date = date('Y-m-d', strtotime($_POST['wsl_acp_date'])); //縣市政府收文日期
    $wsl_acp_num = $_POST['wsl_acp_num']; //縣市政府收文文號

    $wsl_type = $_POST['wsl_type']; //土地編定類別
    $wsl_area = $_POST['wsl_area']; //水庫集水區流域

    $wsl_p_type = $_POST['wsl_p_type']; //土地種類
    $wsl_p_dcp = $_POST['wsl_p_dcp']; //現場位置描述
    $wsl_p_sta = $_POST['wsl_p_sta']; //現場狀況
    
    $wsl_reason = $_POST['wsl_reason']; //清查原因
    if(isset($_POST['wsl_if_ocase'])){
        $wsl_if_ocase = $_POST['wsl_if_ocase']; //是否為原民課案件
    } else {
        $wsl_if_ocase = ""; 
    }
    $wsl_if = $_POST['wsl_if']; //是否為
    if(count($wsl_if) > 1 ){
        array_shift($wsl_if); 
    }
    $wsl_if_list = implode(", ",$wsl_if);

    
    $wsl_vol_num = $_POST['wsl_vol_num']; //身分證(或公司)統一編號
    $wsl_vol_name = $_POST['wsl_vol_name']; //姓名
    $wsl_vol_phone = $_POST['wsl_vol_phone']; //電話
    $wsl_vol_addr = $_POST['wsl_vol_addr']; //地址
    $wsl_remark = $_POST['wsl_remark']; //備註

    if(isset($_POST['wsl_pj_cats'])){
        $wsl_pj_cats = $_POST['wsl_pj_cats']; //土地類別
    } else {
        $wsl_pj_cats = ""; 
    }
    $wsl_pj_no = $_POST['wsl_pj_no']; //土地資料編號
    if(isset($_POST['wsl_pj_own'])){
        $wsl_pj_own = $_POST['wsl_pj_own']; //土地權屬
    } else {
        $wsl_pj_own = ""; 
    }
    if(isset($_POST['wsl_pj_og'])){
        $wsl_pj_og = $_POST['wsl_pj_og']; //公有土地管理機關
    } else {
        $wsl_pj_og = ""; 
    }
    $wsl_pj_area = $_POST['wsl_pj_area']; //土地面積(公頃)

    $wsl_pj_seat_county = $_POST['wsl_pj_seat_county']; //縣市
    $wsl_pj_seat_town = $_POST['wsl_pj_seat_town']; //鄉鎮市區
    $wsl_pj_seat_alley = $_POST['wsl_pj_seat_alley']; //地段
    $wsl_pj_seat_no = $_POST['wsl_pj_seat_no']; //地號
    $wsl_pj_remark = $_POST['wsl_pj_remark']; //備註

    $wsl_pj_co = $_POST['wsl_pj_co']; //坐標資料(TWD97)
    $wsl_ch_date = date('Y-m-d', strtotime($_POST['wsl_ch_date'])); //縣市政府查復日期：
    if(isset($_POST['wsl_ch_result'])){
        $wsl_ch_result = $_POST['wsl_ch_result']; //縣市政府查證結果
    } else {
        $wsl_ch_result = ""; 
    }
    if(isset($_POST['wsl_vl_type'])){
        $wsl_vl_type = $_POST['wsl_vl_type']; //違規法律類別
    } else {
        $wsl_vl_type = ""; 
    }
    $wsl_val_type = $_POST['wsl_val_type']; //違規行政法別
    $wsl_val_cost = $_POST['wsl_val_cost']; //違反行政法已罰鍰金額：
    $wsl_val_area = $_POST['wsl_val_area']; //*違規面積(公頃)
    $wsl_val_item = $_POST['wsl_val_item']; //主違規項目
    if(isset($_POST['wsl_val_crop'])){
        $wsl_val_crop = $_POST['wsl_val_crop']; //現況作物
    } else {
        $wsl_val_crop = ""; 
    }
    $wsl_pu_date = date('Y-m-d', strtotime($_POST['wsl_pu_date'])); //處分日期
    $wsl_val_ph = $_POST['wsl_val_ph']; //行政程序處理紀要
    $wsl_val_ph_item = $_POST['wsl_val_ph_item']; //主違規項目
    $wsl_val_img = $_POST['wsl_val_img']; //現場檢查照片
    $wsl_val_remark = $_POST['wsl_val_remark']; //備註(現場查證狀況描述)
    
    
    $wsl_psh_rate = $_POST['wsl_psh_rate']; //處分次別
    $wsl_psh_name = $_POST['wsl_psh_name']; //受處分人
    if(isset($_POST['wsl_psh_county'])){
        $wsl_psh_county = $_POST['wsl_psh_county']; //縣市
    } else {
        $wsl_psh_county = ""; 
    }
    if(isset($_POST['wsl_psh_town'])){
        $wsl_psh_town = $_POST['wsl_psh_town']; //鄉鎮市區
    } else {
        $wsl_psh_town = ""; 
    }
    if(isset($_POST['wsl_psh_area'])){
        $wsl_psh_area = $_POST['wsl_psh_area']; //違規面積(公頃)
    } else {
        $wsl_psh_area = ""; 
    }
    $wsl_psh_date = date('Y-m-d', strtotime($_POST['wsl_psh_date'])); //處罰日期
    $wsl_psh_num = $_POST['wsl_psh_num']; //處罰文號
    $wsl_psh_cost = $_POST['wsl_psh_cost']; //罰鍰金額(元)
    $wsl_psh_end_date = date('Y-m-d', strtotime($_POST['wsl_psh_end_date'])); //罰鍰完繳日期
    $wsl_psh_deadline = date('Y-m-d', strtotime($_POST['wsl_psh_deadline'])); //限期改正日期
    $wsl_psh_pre = date('Y-m-d', strtotime($_POST['wsl_psh_pre'])); //預先通知限期改正日期
    $wsl_psh_remark = $_POST['wsl_psh_remark']; //備註
    
    $query = "INSERT INTO wslimit(wsl_cats, wsl_source, wsl_town, wsl_county, wsl_alley, wsl_unit, wsl_apy_date, wsl_apy_num, wsl_sent_date, wsl_sent_num, wsl_acp_date, wsl_acp_num, wsl_type, wsl_area, wsl_p_type, wsl_p_dcp, wsl_p_sta, wsl_reason, wsl_if_ocase, wsl_if, wsl_vol_num, wsl_vol_name, wsl_vol_phone, wsl_vol_addr, wsl_remark, wsl_pj_cats, wsl_pj_no, wsl_pj_own, wsl_pj_og, wsl_pj_area, wsl_pj_seat_county, wsl_pj_seat_town, wsl_pj_seat_alley, wsl_pj_seat_no, wsl_pj_remark, wsl_pj_co, wsl_ch_date, wsl_ch_result, wsl_vl_type, wsl_val_type, wsl_val_cost, wsl_val_area, wsl_val_item, wsl_val_crop, wsl_pu_date, wsl_val_ph, wsl_val_ph_item, wsl_val_img, wsl_val_remark, wsl_psh_rate, wsl_psh_name, wsl_psh_county, wsl_psh_town, wsl_psh_area, wsl_psh_date, wsl_psh_num, wsl_psh_cost, wsl_psh_end_date, wsl_psh_deadline, wsl_psh_pre, wsl_psh_remark)";
    $query .=
    "VALUES( '{$wsl_cats}', '{$wsl_source}', '{$wsl_town}', '{$wsl_county}', '{$wsl_alley}', '{$wsl_unit}', '{$wsl_apy_date}', '{$wsl_apy_num}', '{$wsl_sent_date}', '{$wsl_sent_num}', '{$wsl_acp_date}', '{$wsl_acp_num}', '{$wsl_type}', '{$wsl_area}', '{$wsl_p_type}', '{$wsl_p_dcp}', '{$wsl_p_sta}', '{$wsl_reason}', '{$wsl_if_ocase}', '{$wsl_if_list}', '{$wsl_vol_num}', '{$wsl_vol_name}', '{$wsl_vol_phone}', '{$wsl_vol_addr}', '{$wsl_remark}', '{$wsl_pj_cats}', '{$wsl_pj_no}', '{$wsl_pj_own}', '{$wsl_pj_og}', '{$wsl_pj_area}', '{$wsl_pj_seat_county}', '{$wsl_pj_seat_town}', '{$wsl_pj_seat_alley}', '{$wsl_pj_seat_no}', '{$wsl_pj_remark}', '{$wsl_pj_co}', '{$wsl_ch_date}', '{$wsl_ch_result}', '{$wsl_vl_type}', '{$wsl_val_type}', '{$wsl_val_cost}', '{$wsl_val_area}', '{$wsl_val_item}', '{$wsl_val_crop}', '{$wsl_pu_date}', '{$wsl_val_ph}', '{$wsl_val_ph_item}', '{$wsl_val_img}', '{$wsl_val_remark}', '{$wsl_psh_rate}', '{$wsl_psh_name}', '{$wsl_psh_county}', '{$wsl_psh_town}', '{$wsl_psh_area}', '{$wsl_psh_date}', '{$wsl_psh_num}', '{$wsl_psh_cost}', '{$wsl_psh_end_date}', '{$wsl_psh_deadline}', '{$wsl_psh_pre}', '{$wsl_psh_remark}')";


    $WS_add_project = mysqli_query($connection, $query);

    comfirmQuery($WS_add_project, '新增成功', null);
}


// ALL USER
$queryUser = "SELECT * FROM userlist WHERE user_role = 'auther'";
$select_all_user_query = mysqli_query($connection, $queryUser);
$user_fullname = array(); 

while($row = mysqli_fetch_assoc($select_all_user_query)){


    $user_fullname[] = $row['user_fullname']; //姓名
}

// ALL DATA
// $queryData = "SELECT wsl_pj_seat_town, wsl_pj_seat_alley, wsl_pj_seat_no FROM $wslroject";
// $select_all_wsl_query = mysqli_query($connection, $queryData);
// $your_database_data = array();
// while ($row = mysqli_fetch_assoc($select_all_wsl_query)) {
//     $your_database_data[] = $row;
// }
?>


<main>
    <div class="container-fluid p-4">
        <div class="_POST">
            <div class="col-12">
                <h1 class="h4 mb-4">新增 超限利用案件</h1>
            </div>
            <form action="" method="post">
            <div class="p-4 mb-4 bg-light text-dark rounded">
                <h2 class="h5 mb-4">超限利用案件內容

                </h2>
                
                <div class="accordion accordion-flush mb-3" id="maincontent">
                    <div class="accordion-item">
                        <h2 class="accordion-header" id="flush-headingOne">
                            <button class="accordion-button" type="button" data-bs-toggle="collapse" data-bs-target="#flush-collapseOne" aria-expanded="true" aria-controls="flush-collapseOne">
                                基本資料
                            </button>
                        </h2>
                        <div id="flush-collapseOne" class="accordion-collapse collapse show" aria-labelledby="flush-headingOne" data-bs-parent="#maincontent">
                            <div class="accordion-body">
                                <label for="wsl_cats" class="col-form-label">案件類別</label>
                                <div class="input-group ">
                                    <div class="form-check form-check-inline">
                                        <input class="form-check-input" type="radio" name="wsl_cats" id="wsl_cats_t"  value="0" checked>
                                        <label class="form-check-label" for="wsl_cats_t">農業使用</label>
                                    </div>
                                    <div class="form-check form-check-inline">
                                        <input class="form-check-input" type="radio" name="wsl_cats" id="wsl_cats_y"  value="1" >
                                        <label class="form-check-label" for="wsl_cats_y">非農業使用</label>
                                    </div>
                                </div>

                                <label for="wsl_source" class="col-form-label">查報主資訊來源</label>
                                <select id="wsl_source" name="wsl_source" class="form-select">
                                    <option value="" selected disabled>請選擇</option>
                                    <option value="依行政區">依行政區</option>
                                    <option value="依行為人">依行為人</option>
                                    <option value="未依計畫施作案件">未依計畫施作案件</option>
                                </select>   

                                <label for="wsl_county" class="col-form-label">鄉市</label>
                                <div  class="input-group mb-2">

                                    <select class="form-select" id="wsl_county" name="wsl_county">
                                        <option value="雲林縣" selected>雲林縣</option>
                                    </select> 

                                    <select class="form-select" id="wss_pj_seat_town" name="wsl_town">
                                        <option value="" selected >請選擇</option>
                                        <?php
                                            $areaitem = '[{"area":"斗六市","value":"斗六市"},{"area":"古坑鄉","value":"古坑鄉"},{"area":"林內鄉","value":"林內鄉"}]';
                                            $areaitem_array = json_decode( $areaitem, true );
                                            
                                            foreach($areaitem_array as $item) { 
                                                $value = $item['value'];
                                                $area = $item['area'];
                                                
                                                echo "<option value='$value'  >$area</option>";
                                            }
                                        ?>
                                    </select>
                                    <input id="road" type="hidden" value="<?php echo $wsl_alley?>">

                                    <select class="form-select" id="wss_pj_seat_alley" name="wsl_alley">
                                        <option value="" selected>請選擇</option>
                                    </select>
                                </div>
                                <label for="wsl_unit" class="col-form-label">案件移來單位</label>
                                <input type="text" class="form-control" id="wsl_unit" name="wsl_unit">
                                <label for="wsl_apy_date" class="col-form-label">查(通)報日期</label>
                                <div class="input-group ">
                                    <input type="date" class="form-control" name="wsl_apy_date">
                                    <span class="input-group-text"><i class="fas fa-calendar"></i></span>
                                </div>
                                <label for="wsl_apy_num" class="col-form-label">查(通)報文號</label>
                                <input type="text" class="form-control" id="wsl_apy_num" name="wsl_apy_num">
                                <label for="wsl_sent_date" class="col-form-label">農村發展及水土保持署函送日期</label>
                                <div class="input-group ">
                                    <input type="date" class="form-control" name="wsl_sent_date">
                                    <span class="input-group-text"><i class="fas fa-calendar"></i></span>
                                </div>
                                <label for="wsl_sent_num" class="col-form-label">農村發展及水土保持署函送文號</label>
                                <input type="text" class="form-control" id="wsl_sent_num" name="wsl_sent_num">
                                <label for="wsl_acp_date" class="col-form-label">縣市政府收文日期</label>
                                <div class="input-group ">
                                    <input type="date" class="form-control" name="wsl_acp_date">
                                    <span class="input-group-text"><i class="fas fa-calendar"></i></span>
                                </div>
                                <label for="wsl_acp_num" class="col-form-label">縣市政府收文文號</label>
                                <input type="text" class="form-control" id="wsl_acp_num" name="wsl_acp_num">
                                <label for="wsl_type" class="col-form-label">土地編定類別</label>
                                <input type="text" class="form-control" id="wsl_type" name="wsl_type">
                                <label for="wsl_area" class="col-form-label">水庫集水區流域</label>
                                <input type="text" class="form-control" id="wsl_area" name="wsl_area">
                                
                                <label for="wsl_p_type" class="col-form-label">土地種類 <span class='text-danger'>*</span></label>
                                <div class="input-group ">
                                    <div class="form-check form-check-inline">
                                        <input class="form-check-input" type="radio" name="wsl_p_type" id="wsl_p_type_t"  value="0" checked>
                                        <label class="form-check-label" for="wsl_p_type_t">都市土地</label>
                                    </div>
                                    <div class="form-check form-check-inline">
                                        <input class="form-check-input" type="radio" name="wsl_p_type" id="wsl_p_type_y"  value="1" >
                                        <label class="form-check-label" for="wsl_p_type_y">非都市土地</label>
                                    </div>
                                </div> 
                                
                                <label for="wsl_p_dcp" class="col-form-label">現場位置描述</label>
                                <input type="text" class="form-control" id="wsl_p_dcp" name="wsl_p_dcp">
                                <label for="wsl_p_sta" class="col-form-label">現場狀況</label>
                                <input type="text" class="form-control" id="wsl_p_sta" name="wsl_p_sta">
                                
                                <label for="wsl_reason" class="col-form-label">清查原因 <span class='text-danger'>*</span></label>
                                <div class="input-group ">
                                    <div class="form-check form-check-inline">
                                        <input class="form-check-input" type="radio" name="wsl_reason" id="wsl_reason_1"  value="1">
                                        <label class="form-check-label" for="wsl_reason_1">因恢復自然植生解除列管</label>
                                    </div>
                                    <div class="form-check form-check-inline">
                                        <input class="form-check-input" type="radio" name="wsl_reason" id="wsl_reason_2"  value="2" checked>
                                        <label class="form-check-label" for="wsl_reason_2">因非農業使用解除列管</label>
                                    </div>
                                    <div class="form-check form-check-inline">
                                        <input class="form-check-input" type="radio" name="wsl_reason" id="wsl_reason_3"  value="3" checked>
                                        <label class="form-check-label" for="wsl_reason_3">改正清查工作</label>
                                    </div>
                                    <div class="form-check form-check-inline">
                                        <input class="form-check-input" type="radio" name="wsl_reason" id="wsl_reason_4"  value="0" checked>
                                        <label class="form-check-label" for="wsl_reason_4">其他</label>
                                    </div>
                                </div> 

                                <label for="wsl_if_ocase" class="col-form-label">是否為原民課案件 <span class='text-danger'>*</span></label>
                                <select id="wsl_if_ocase" name="wsl_if_ocase" class="form-select">
                                    <option value="" selected disabled>請選擇</option>
                                    <option value="是">是</option>
                                    <option value="否">否</option>
                                </select>   
                                <label for="wsl_if" class="col-form-label">是否為 <span class='text-danger'>*</span></label>
                                <input type="hidden" name="wsl_if[]" value="無" checked>
                                <?php
                                        $type = '[{"name":"土石流潛勢區"},
                                        {"name":"集水區"},
                                        {"name":"水源水質水量保護區及水源特定區"},
                                        {"name":"檳榔管理方案"}]';
                                    $type_array = json_decode( $type, true );

                                    foreach($type_array as $key=>$item) { 
                                        $name = $item['name']; 
                                        
                                        echo "<div class='form-check'>";
                                        echo "<input class='form-check-input' type='checkbox' name='wsl_if[]' value='$name' id='type$key'> ";
                                        echo "<label class='form-check-label' for='type$key'>";
                                        echo "$name";
                                        echo "</label>";
                                        echo "</div>";
                                    }

                                    
                                ?>

                               
                            </div>
                        </div>
                    </div>
                    <div class="accordion-item">
                        <h2 class="accordion-header" id="flush-headingTwo">
                            <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#flush-collapseTwo" aria-expanded="false" aria-controls="flush-collapseTwo">
                            行為人資料
                            </button>
                        </h2>
                        <div id="flush-collapseTwo" class="accordion-collapse collapse "
                            aria-labelledby="flush-headingTwo" data-bs-parent="#maincontent">
                            <div class="accordion-body">
                            <?php
                                $vol = '[{"title_cn":"身分證(或公司)統一編號","title_en":"wsl_vol_num","type":"text","required":"false"},
                                {"title_cn":"姓名","title_en":"wsl_vol_name","type":"text","required":"true"},
                                {"title_cn":"電話","title_en":"wsl_vol_phone","type":"text","required":"false"},
                                {"title_cn":"地址","title_en":"wsl_vol_addr","type":"text","required":"false"}]';
                                $vol_array = json_decode( $vol, true );

                                foreach($vol_array as $item) { 
                                    $title_cn = $item['title_cn']; 
                                    $title_en = $item['title_en']; 
                                    $type = $item['type']; 
                                    $required = $item['required']; 
                                    if ($required == 'true'){
                                        $required = "";
                                        $star = "<span class='text-danger'>*</span>";
                                    }else{
                                        $required = "";
                                        $star = "";
                                    }
                                    echo "<label for='$title_en' class='col-form-label'>$title_cn $star</label>";
                                    echo "<input id='$title_en' name='$title_en' type='$type' class='form-control' $required>";
                                }
                            ?>
                                <label for="wsl_remark" class="col-form-label">備註</label>
                                <textarea class="form-control" name="wsl_remark" id="wsl_remark" ></textarea>

                            </div>
                        </div>
                    </div>
                    <div class="accordion-item">
                        <h2 class="accordion-header" id="flush-headingThree">
                            <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse"
                                data-bs-target="#flush-collapseThree" aria-expanded="false"
                                aria-controls="flush-collapseThree">
                                土地資料
                            </button>
                        </h2>
                        <div id="flush-collapseThree" class="accordion-collapse collapse "
                            aria-labelledby="flush-headingThree" data-bs-parent="#maincontent">
                            <div class="accordion-body">
                                <label for="wsl_pj_cats" class="col-form-label">土地類別</label>
                                <select id="wsl_pj_cats" name="wsl_pj_cats" class="form-select">
                                    <option value="" selected>請選擇</option>

                                    <option value="地籍資料">地籍資料</option>
                                    <option value="林班資料">林班資料</option>
                                    <option value="暫未編定">暫未編定</option>
                                </select>  
                                 
                                <label for="wsl_pj_no" class="col-form-label">土地資料編號</label>
                                <input type="text" class="form-control" id="wsl_pj_no" name="wsl_pj_no">
                                <label for="wsl_pj_own" class="col-form-label">土地權屬<span class='text-danger'>*</span></label>
                                <select id="wsl_pj_own" name="wsl_pj_own" class="form-select">
                                    <option value="" selected disabled>請選擇</option>
                                    <option value="公有">公有</option>
                                    <option value="私有">私有</option>
                                    <option value="公、私有">公、私有</option>
                                </select>   
                                <label for="wsl_pj_og" class="col-form-label">公有土地管理機關</label>
                                <select id="wsl_pj_og" name="wsl_pj_og" class="form-select">
                                    <option value="" selected disabled>請選擇</option>
                                    <option value="原住民委員會">原住民委員會</option>
                                    <option value="財政部國有財產署">財政部國有財產署</option>
                                    <option value="農業部林業及自然保育署">農業部林業及自然保育署</option>
                                    <option value="其他">其他</option>
                                </select>   
                                
                                <label for="wsl_pj_area" class="col-form-label">土地面積(公頃)</label>
                                <input type="text" class="form-control" id="wsl_pj_area" name="wsl_pj_area">
                                
                                <label for="wsl_pj_seat_county" class="col-form-label">鄉市</label>
                                <div  class="input-group mb-2">

                                    <select class="form-select" id="wsl_pj_seat_county" name="wsl_pj_seat_county">
                                        <option value="雲林縣" selected>雲林縣</option>
                                    </select> 

                                    <select class="form-select" id="wsl_pj_seat_town" name="wsl_pj_seat_town">
                                        <option value="" selected >請選擇</option>
                                        <?php
                                            $areaitem = '[{"area":"斗六市","value":"斗六市"},{"area":"古坑鄉","value":"古坑鄉"},{"area":"林內鄉","value":"林內鄉"}]';
                                            $areaitem_array = json_decode( $areaitem, true );
                                            
                                            foreach($areaitem_array as $item) { 
                                                $value = $item['value'];
                                                $area = $item['area'];
                                                
                                                echo "<option value='$value'  >$area</option>";
                                            }
                                        ?>
                                    </select>
                                    <input id="road" type="hidden" value="<?php echo $wsl_pj_seat_alley?>">

                                    <select class="form-select" id="wsl_pj_seat_alley" name="wsl_pj_seat_alley">
                                        <option value="" selected>請選擇</option>
                                    </select>
                                    
                                    
                                </div>
                                <label for="wsl_pj_seat_no" class="col-form-label">地號</label>
                                <input id="wsl_pj_seat_no" type="text" class="form-control"  name="wsl_pj_seat_no" placeholder="請輸入地號">
                                <label for="wsl_pj_remark" class="col-form-label">備註</label>
                                <textarea class="form-control" name="wsl_pj_remark" id="wsl_pj_remark" ></textarea>
                            </div>
                        </div>
                    </div>
                    <div class="accordion-item">
                        <h2 class="accordion-header" id="flush-headingFour">
                            <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse"
                                data-bs-target="#flush-collapseFour" aria-expanded="false"
                                aria-controls="flush-collapseFour">
                                查證結果
                            </button>
                        </h2>
                        <div id="flush-collapseFour" class="accordion-collapse collapse "
                            aria-labelledby="flush-headingFour" data-bs-parent="#maincontent">
                            <div class="accordion-body">
                                <label for="" class="col-form-label">坐標資料(TWD97) </label>
                                <div class="input-group mb-3">
                                    <input id="latlng" type="text" class="form-control" name="wsl_pj_co" data-lat="23.6743232" data-lng="120.4345919" value="">
                                    <span class="input-group-text" id=""><i class="fas fa-map-marker-alt"></i></span>
                                </div>
                                <label for="wsl_ch_date" class="col-form-label">縣市政府查復日期</label>
                                <div class="input-group ">
                                    <input type="date" class="form-control" name="wsl_ch_date">
                                    <span class="input-group-text"><i class="fas fa-calendar"></i></span>
                                </div>
                                <label for="wsl_ch_result" class="col-form-label">縣市政府查證結果</label>
                                <select id="wsl_ch_result" name="wsl_ch_result" class="form-select">
                                    <option value="" selected disabled>請選擇</option>
                                    <option value="違規案件">違規案件</option>
                                    <option value="非違規案件">非違規案件</option>
                                </select> 
                                <label for="wsl_vl_type" class="col-form-label">違規法律類別</label>
                                <select id="wsl_vl_type" name="wsl_vl_type" class="form-select">
                                    <option value="" selected disabled>請選擇</option>
                                    <option value="觸及刑事法律">觸及刑事法律</option>
                                    <option value="違反行政法">違反行政法</option>
                                    <option value="同時觸及刑事法律及違反行政法">同時觸及刑事法律及違反行政法</option>
                                </select> 

                                <label for="wsl_val_type" class="col-form-label">違規行政法別</label>
                                <input type="text" class="form-control" id="wsl_val_type" name="wsl_val_type">

                                <label for="wsl_val_cost" class="col-form-label">違反行政法已罰鍰金額</label>
                                <input type="text" class="form-control" id="wsl_val_cost" name="wsl_val_cost">

                                <label for="wsl_val_area" class="col-form-label">違規面積(公頃) <span class='text-danger'>*</span></label>
                                <input type="text" class="form-control" id="wsl_val_area" name="wsl_val_area">
                                <label for="wsl_val_item" class="col-form-label">主違規項目 <span class='text-danger'>*</span></label>
                                <select class="form-select" id="wsl_val_item" name="wsl_val_item" >
                                    <option value="" selected>請選擇</option>
                                    <option value="01a違規農業使用">01a違規農業使用</option>
                                    <option value="01b超限利用">01b超限利用</option>
                                    <option value="02開發建築用地">02開發建築用地</option>
                                    <option value="03採取土石">03採取土石</option>
                                    <option value="04修建道路或溝渠">04修建道路或溝渠(含鐵、公路)</option>
                                    <option value="05探礦、採礦">05探礦、採礦</option>
                                    <option value="06堆積土石">06堆積土石</option>
                                    <option value="07設置供原、遊憩用地、運動場地或軍事訓練場">07設置供原、遊憩用地、運動場地或軍事訓練場</option>
                                    <option value="08設置墳墓">08設置墳墓</option>
                                    <option value="09處理廢棄物">09處理廢棄物</option>
                                    <option value="10其他開挖整地">10其他開挖整地</option>
                                    <option value="11未依核定計畫施工">11未依核定計畫施工</option>
                                    <option value="12未依規定限期改正">12未依規定限期改正</option>
                                    <option value="13整坡作業">13整坡作業</option>
                                </select>
                                <label for="wsl_val_crop" class="col-form-label">現況作物 <span class='text-danger'>*</span></label>
                                <div class="input-group ">
                                    <div class="form-check form-check-inline">
                                        <input class="form-check-input" type="radio" name="wsl_val_crop" id="wsl_val_crop_1"  value="1">
                                        <label class="form-check-label" for="wsl_val_crop_1">檳榔</label>
                                    </div>
                                    <div class="form-check form-check-inline">
                                        <input class="form-check-input" type="radio" name="wsl_val_crop" id="wsl_val_crop_2"  value="2">
                                        <label class="form-check-label" for="wsl_val_crop_2">果樹</label>
                                    </div>
                                    <div class="form-check form-check-inline">
                                        <input class="form-check-input" type="radio" name="wsl_val_crop" id="wsl_val_crop_3"  value="3">
                                        <label class="form-check-label" for="wsl_val_crop_3">茶樹</label>
                                    </div>
                                    <div class="form-check form-check-inline">
                                        <input class="form-check-input" type="radio" name="wsl_val_crop" id="wsl_val_crop_4"  value="4">
                                        <label class="form-check-label" for="wsl_val_crop_4">蔬菜等草本植物</label>
                                    </div>
                                    <div class="form-check form-check-inline">
                                        <input class="form-check-input" type="radio" name="wsl_val_crop" id="wsl_val_crop_5"  value="5">
                                        <label class="form-check-label" for="wsl_val_crop_5">其他</label>
                                    </div>
                                    
                                </div> 
                                <label for="wsl_pu_date" class="col-form-label">處分日期：(開立處分書)</label>
                                <div class="input-group ">
                                    <input type="date" class="form-control" name="wsl_pu_date">
                                    <span class="input-group-text"><i class="fas fa-calendar"></i></span>
                                </div>
                                <label for="wsl_val_ph" class="col-form-label">行政程序處理紀要</label>
                                <input type="text" class="form-control" id="wsl_val_ph" name="wsl_val_ph">
                                <label for="wsl_val_ph_item" class="col-form-label">主違規項目 <span class='text-danger'>*</span></label>
                                <select class="form-select" id="wsl_val_ph_item" name="wsl_val_ph_item" >
                                    <option value="" selected>請選擇</option>
                                    <option value="01a違規農業使用">01a違規農業使用</option>
                                    <option value="01b超限利用">01b超限利用</option>
                                    <option value="02開發建築用地">02開發建築用地</option>
                                    <option value="03採取土石">03採取土石</option>
                                    <option value="04修建道路或溝渠">04修建道路或溝渠(含鐵、公路)</option>
                                    <option value="05探礦、採礦">05探礦、採礦</option>
                                    <option value="06堆積土石">06堆積土石</option>
                                    <option value="07設置供原、遊憩用地、運動場地或軍事訓練場">07設置供原、遊憩用地、運動場地或軍事訓練場</option>
                                    <option value="08設置墳墓">08設置墳墓</option>
                                    <option value="09處理廢棄物">09處理廢棄物</option>
                                    <option value="10其他開挖整地">10其他開挖整地</option>
                                    <option value="11未依核定計畫施工">11未依核定計畫施工</option>
                                    <option value="12未依規定限期改正">12未依規定限期改正</option>
                                    <option value="13整坡作業">13整坡作業</option>
                                </select>
                                <label for="wsl_val_img" class="col-form-label">現場檢查照片</label>
                                <div class="input-group">
                                    <input type="file" class="form-control" id="wsl_val_img" name="wsl_val_img" >
                                    <span class="input-group-text" ><i class="fas fa-image"></i></span>
                                </div>
                                <label for="wsl_val_remark" class="col-form-label">備註(現場查證狀況描述)</label>
                                <textarea class="form-control" name="wsl_val_remark" id="wsl_val_remark" ></textarea>

                            </div>
                        </div>
                    </div>
                    <div class="accordion-item">
                        <h2 class="accordion-header" id="flush-headingFive">
                            <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse"
                                data-bs-target="#flush-collapseFive" aria-expanded="false"
                                aria-controls="flush-collapseFive">
                                行政處分
                            </button>
                        </h2>
                        <div id="flush-collapseFive" class="accordion-collapse collapse "
                            aria-labelledby="flush-headingFive" data-bs-parent="#maincontent">
                            <div class="accordion-body">
                            <div class="accordion-body">
                                <label for="wsl_psh_rate" class="col-form-label">處分次別</label>
                                <input id="wsl_psh_rate" name="wsl_psh_rate" type="text" class="form-control">
                                <label for="wsl_psh_name" class="col-form-label">受處分人 <span class='text-danger'>*</span></label>
                                <input id="wsl_psh_name" name="wsl_psh_name" type="text" class="form-control" >
                                <label for="wsl_psh_county" class="col-form-label">縣市(與基本資料相同)</label>
                                <input type="text" class="form-control" id="wsl_psh_county" name="wsl_psh_county" disabled value="雲林縣">
                                <label for="wsl_psh_town" class="col-form-label">鄉鎮市區(與基本資料相同)</label>  
                                <input type="text" class="form-control" id="wsl_psh_town" name="wsl_psh_town" disabled value="">
                                <label for="wsl_psh_area" class="col-form-label">違規面積(公頃)</label>
                                <div class="input-group ">
                                    <input type="number" step="0.0001" class="form-control" id="wsl_psh_area" name="wsl_psh_area" disabled value="0.0000">
                                    <span class="input-group-text" >公頃</span>
                                </div>

                                <label for="wsl_psh_date" class="col-form-label">處罰日期</label>
                                <div id="wsl_psh_date" class="input-group">
                                    <input type="date" class="form-control" name="wsl_psh_date" >
                                    <span class="input-group-text"><i class="fas fa-calendar"></i></span>
                                </div>
                                <label for="wsl_psh_num" class="col-form-label">處罰文號</label>
                                <input type="text" class="form-control" id="wsl_psh_num" name="wsl_psh_num">
                                <label for="wsl_psh_cost" class="col-form-label">罰鍰金額(元)</label>
                                <div class="input-group">
                                    <input id="wsl_psh_cost" type="number" step="1" class="form-control" name="wsl_psh_cost" value="0">
                                    <span class="input-group-text"><i class="fas fa-dollar-sign"></i></span>
                                </div>
                                <label id="wsl_psh_end_date" for="wsl_psh_end_date" class="col-form-label">罰鍰完繳日期</label>
                                <div class="input-group">
                                    <input id="wsl_psh_end_date" type="date" class="form-control" name="wsl_psh_end_date">
                                    <span class="input-group-text"><i class="fas fa-calendar"></i></span>
                                </div>
                                <label id="wsl_psh_deadline" for="wsl_psh_deadline" class="col-form-label">限期改正日期</label>
                                <div class="input-group">
                                    <input id="wsl_psh_deadline" type="date" class="form-control" name="wsl_psh_deadline" onchange="end(value)">
                                    <span class="input-group-text"><i class="fas fa-calendar"></i></span>
                                </div>
                                <label for="wsl_psh_pre" class="col-form-label">預先通知限期改正日期</label>
                                <div class="input-group">
                                    <input id="wsl_psh_pre" type="date" class="form-control" name="wsl_psh_pre">
                                    <span class="input-group-text"><i class="fas fa-calendar"></i></span>
                                </div>
                                <label for="wsl_psh_remark" class="col-form-label">備註</label>
                                <div class="input-group">
                                    <input id="wsl_psh_remark" type="text" class="form-control" name="wsl_psh_remark">
                                    <span class="input-group-text"><i class="fas fa-user"></i></span>
                                </div>
                            </div>
                            </div>
                        </div>
                    </div>

                </div>
                <div class="d-grid gap-2 d-md-flex justify-content-md-end">
                        <a class="btn btn-secondary " href="wslimit.php"><i
                                class="fas fa-times-circle me-2"></i>取消</a>
                        <input class="btn btn-primary" type="submit" name="add_project" value="儲存">
                        <!-- <button class="btn btn-dark " type="button"><i class="fas fa-file-export me-2"></i>匯出</button> -->
                </div>
            </div>
            </form>

        </div>
    </div>
</main>
<script src="./assets/map.js"></script>
<script src="./assets/street.js"></script>

<script>

    // 確認土地位置是否重複
    document.addEventListener("DOMContentLoaded", function() {
        var townSelect = document.getElementById("wsl_town");
        var alleySelect = document.getElementById("wsl_alley");
        var seatNoInput = document.getElementById("wss_pj_seat_no");

        townSelect.addEventListener("change", checkForDuplicates);
        alleySelect.addEventListener("change", checkForDuplicates);
        seatNoInput.addEventListener("change", checkForDuplicates);

        function checkForDuplicates() {
            var selectedTown = townSelect.value;
            var selectedAlley = alleySelect.value;
            var selectedSeatNo = seatNoInput.value;

            if (selectedTown !== '' && selectedAlley !== '' && selectedSeatNo !== '') {
                var isDuplicate = your_database_data.some(function (data) {
                    return (
                        data.wss_pj_seat_town === selectedTown &&
                        data.wss_pj_seat_alley === selectedAlley &&
                        data.wss_pj_seat_no === selectedSeatNo
                    );
                });

                if (isDuplicate) {
                    alert("已存在相同的地點座落和座號。");
                }
            }
        }

        var your_database_data = <?php echo json_encode($your_database_data); ?>;

    });
    

    const undertakerSelect = document.getElementById("wsl_undertaker_select");
    const selectedUndertaker = document.getElementById("selected-undertaker");
    const wslRmCrew = document.getElementById("wsl_rm_crew");

    undertakerSelect.addEventListener("change", function() {
        const selectedValue = undertakerSelect.value;
        selectedUndertaker.textContent = selectedValue;
        wslRmCrew.value = selectedValue;

    });


    // 提醒完工日期
    function end(val, index) {
        date = new Date(val);
        rm_end = date.setDate(date.getDate() - 20);
        rm_end_d = new Date(rm_end);

        wss_rm_end_date = convertDate(rm_end_d);
        document.getElementById('wsl_rm_end_date').value = wss_rm_end_date;

    }
    
    function convertDate(date) {
        var yyyy = date.getFullYear().toString();
        var mm = (date.getMonth()+1).toString();
        var dd  = date.getDate().toString();
        
        var mmChars = mm.split('');
        var ddChars = dd.split('');
        
        return yyyy + '-' + (mmChars[1]?mm:"0"+mmChars[0]) + '-' + (ddChars[1]?dd:"0"+ddChars[0]);
    }
    
    // 承辦人、提醒通知人員
    function utaker(val){
        document.getElementById('undertaker').value = val; 
        document.getElementById('wsl_rm_crew').value = val; 
    }
    // 申請申報日期
    function de(val){
        document.getElementById('wsl_apy_date').value = val; 
    }
    // 申請文號
    function num(val){
        document.getElementById('apy_tnum').value = val; 
    }


    function rmd(){
        date2 = new Date(document.getElementById('wsl_st_date').value)
        rm = date2.setDate(date2.getDate()-20)
        rm_d = new Date(rm)
        wsl_rm_st_date = convertDate(rm_d)
        document.getElementById('wsl_rm_st_date').value = wsl_rm_st_date; 

    }
    // 應開工日期
    function apy(val){
        date = new Date(val)
        st = date.setDate(date.getDate()+365)
        st_d = new Date(st)

        wsl_st_date = convertDate(st_d)
        document.getElementById('wsl_st_date').value = wsl_st_date; 
        rmd();

    }
    // 提醒完工日期
    function end(val){
        date = new Date(val)
        rm_end = date.setDate(date.getDate()-20)
        rm_end_d = new Date(rm_end)

        wsl_rm_end_date = convertDate(rm_end_d)
        document.getElementById('wsl_rm_end_date').value = wsl_rm_end_date; 
    }

</script>